package main

import (
	"flag"
	"fmt"
	"log"
	"net/http"
	"net/url"
	"os"
	"path/filepath"
	"strconv"
	"time"
	"io/ioutil"
	"runtime"
	"os/exec"

	fsnotify "github.com/fsnotify/fsnotify"
	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/promhttp"
)

const namespace = "configmap_reload"

var (
	configVolumeDir   = flag.String("configVolumeDir", "/etc/config", "Path where the config file needs to be updated")
	secretVolumeDir   = flag.String("secretVolumeDir", "/var/run/secrets", "Path where the config file needs to be updated")
	webhook           webhookFlag
	configUpdateFile  = flag.String("configFilePath", "/data/config.yml", "Path where the config file needs to be updated")
	webhookMethod     = flag.String("webhook-method", "POST", "the HTTP method url to use to send the webhook")
	webhookStatusCode = flag.Int("webhook-status-code", 200, "the HTTP status code indicating successful triggering of reload")
	webhookRetries    = flag.Int("webhook-retries", 1, "the amount of times to retry the webhook reload request")
	listenAddress     = flag.String("web.listen-address", ":9533", "Address to listen on for web interface and telemetry.")
	metricPath        = flag.String("web.telemetry-path", "/metrics", "Path under which to expose metrics.")

	lastReloadError = prometheus.NewGaugeVec(prometheus.GaugeOpts{
		Namespace: namespace,
		Name:      "last_reload_error",
		Help:      "Whether the last reload resulted in an error (1 for error, 0 for success)",
	}, []string{"webhook"})
	requestDuration = prometheus.NewGaugeVec(prometheus.GaugeOpts{
		Namespace: namespace,
		Name:      "last_request_duration_seconds",
		Help:      "Duration of last webhook request",
	}, []string{"webhook"})
	successReloads = prometheus.NewCounterVec(prometheus.CounterOpts{
		Namespace: namespace,
		Name:      "success_reloads_total",
		Help:      "Total success reload calls",
	}, []string{"webhook"})
	requestErrorsByReason = prometheus.NewCounterVec(prometheus.CounterOpts{
		Namespace: namespace,
		Name:      "request_errors_total",
		Help:      "Total request errors by reason",
	}, []string{"webhook", "reason"})
	configWatcherErrors = prometheus.NewCounter(prometheus.CounterOpts{
		Namespace: namespace,
		Name:      "configWatcher_errors_total",
		Help:      "Total filesystem configWatcher errors",
	})
	secretWatcherErrors = prometheus.NewCounter(prometheus.CounterOpts{
		Namespace: namespace,
		Name:      "secretWatcher_errors_total",
		Help:      "Total filesystem secretWatcher errors",
	})
	requestsByStatusCode = prometheus.NewCounterVec(prometheus.CounterOpts{
		Namespace: namespace,
		Name:      "requests_total",
		Help:      "Total requests by response status code",
	}, []string{"webhook", "status_code"})
)

func init() {
	prometheus.MustRegister(lastReloadError)
	prometheus.MustRegister(requestDuration)
	prometheus.MustRegister(successReloads)
	prometheus.MustRegister(requestErrorsByReason)
	prometheus.MustRegister(configWatcherErrors)
	prometheus.MustRegister(secretWatcherErrors)
	prometheus.MustRegister(requestsByStatusCode)
}

func main() {
	flag.Var(&webhook, "webhook-url", "the url to send a request to when the specified config map volume directory has been updated")
	flag.Parse()


	if len(webhook) < 1 {
		log.Println("Missing webhook-url")
		log.Println()
		flag.Usage()
		os.Exit(1)
	}

	configWatcher, err := fsnotify.NewWatcher()
	if err != nil {
		log.Fatal(err)
	}
	defer configWatcher.Close()

	secretWatcher, err := fsnotify.NewWatcher()
	if err != nil {
		log.Fatal(err)
	}
	defer secretWatcher.Close()

	go func() {
		for {
			select {
			case event := <-configWatcher.Events:
				if !isValidEvent(event) {
					continue
				}
				log.Println("configMap Update detected")
				convertSecretVolMountToEnvs()
				updateConfigMapWithEnvs()
				sendWebhook()
			case event := <-secretWatcher.Events:
				if !isValidEvent(event) {
					continue
				}
				log.Println("secret Update detected")
				convertSecretVolMountToEnvs()
				updateConfigMapWithEnvs()
				sendWebhook()
			case err := <-configWatcher.Errors:
				configWatcherErrors.Inc()
				log.Println("error:", err)
			case err := <-secretWatcher.Errors:
				secretWatcherErrors.Inc()
				log.Println("error:", err)
			}
		}
	}()
	
	convertSecretVolMountToEnvs()
	updateConfigMapWithEnvs()

	err = configWatcher.Add(*configVolumeDir)
	if err != nil {
		log.Fatal(err)
	}

	err = secretWatcher.Add(*secretVolumeDir)
	if err != nil {
		log.Fatal(err)
	}


	log.Fatal(serverMetrics(*listenAddress, *metricPath))
}

func sendWebhook() {
	for _, h := range webhook {
		begun := time.Now()
		req, err := http.NewRequest(*webhookMethod, h.String(), nil)
		if err != nil {
			setFailureMetrics(h.String(), "client_request_create")
			log.Println("error:", err)
			continue
		}
		userInfo := h.User
		if userInfo != nil {
			if password, passwordSet := userInfo.Password(); passwordSet {
				req.SetBasicAuth(userInfo.Username(), password)
			}
		}

		successfulReloadWebhook := false

		for retries := *webhookRetries; retries != 0; retries-- {
			log.Printf("performing webhook request (%d/%d)", retries, *webhookRetries)
			resp, err := http.DefaultClient.Do(req)
			if err != nil {
				setFailureMetrics(h.String(), "client_request_do")
				log.Println("error:", err)
				time.Sleep(time.Second * 10)
				continue
			}
			resp.Body.Close()
			requestsByStatusCode.WithLabelValues(h.String(), strconv.Itoa(resp.StatusCode)).Inc()
			if resp.StatusCode != *webhookStatusCode {
				setFailureMetrics(h.String(), "client_response")
				log.Println("error:", "Received response code", resp.StatusCode, ", expected", *webhookStatusCode)
				time.Sleep(time.Second * 10)
				continue
			}

			setSuccessMetrics(h.String(), begun)
			log.Println("successfully triggered reload")
			successfulReloadWebhook = true
			break
		}

		if !successfulReloadWebhook {
			setFailureMetrics(h.String(), "retries_exhausted")
			log.Println("error:", "Webhook reload retries exhausted")
		}
	}
}

func setFailureMetrics(h, reason string) {
	requestErrorsByReason.WithLabelValues(h, reason).Inc()
	lastReloadError.WithLabelValues(h).Set(1.0)
}

func setSuccessMetrics(h string, begun time.Time) {
	requestDuration.WithLabelValues(h).Set(time.Since(begun).Seconds())
	successReloads.WithLabelValues(h).Inc()
	lastReloadError.WithLabelValues(h).Set(0.0)
}

func isValidEvent(event fsnotify.Event) bool {
	if event.Op&fsnotify.Write == fsnotify.Write {
		return true
	}
	if event.Op&fsnotify.Create != fsnotify.Create {
		return false
	}
	if filepath.Base(event.Name) != "..data" {
		return false
	}
	return true
}

func convertSecretVolMountToEnvs(){
	files, err := ioutil.ReadDir(*secretVolumeDir)
	if err != nil {
		log.Fatal(err)
	}

	for _, file := range files {
		//Skip directories/files that start with . or ..
		if file.IsDir() || file.Mode().IsDir() || file.Name() == "." || file.Name() == ".." || filepath.HasPrefix(file.Name(), ".."){
			log.Printf("Skipping directory: %q", file.Name())
			continue
		}

		// Retrieve the filename from the filepath
		envFilePath := filepath.Join(*secretVolumeDir, file.Name())
		log.Printf("reading file: %q", envFilePath)
		// Read the contents of the file into a byte slice
		fileContents, err := ioutil.ReadFile(envFilePath)
		if err != nil {
			log.Printf("Error occurred while reading secret file %s\n",envFilePath)
			panic(err)
		}

		// Set the environment variable to the contents of the file
		os.Setenv(file.Name(), string(fileContents))
		setSystemEnvVariable(file.Name(), string(fileContents))
	}
}

func updateConfigMapWithEnvs(){
	configFilePath := filepath.Join(*configVolumeDir, "config.yml")
	
	// Read the file contents into a byte slice.
	fileBytes, err := ioutil.ReadFile(configFilePath)
	if err != nil {
		fmt.Println("Error reading file:\n", err)
		return
	}

	// Convert the byte slice to a string.
	fileString := string(fileBytes)

	// Perform variable substitution on the string.
	envString := os.ExpandEnv(fileString)

	err = ioutil.WriteFile(*configUpdateFile, []byte(envString), 0644)
	if err != nil {
		fmt.Println("Error writing file:\n", err)
	}
}

func setSystemEnvVariable(key, value string) error {
	if runtime.GOOS == "windows" {
		cmd := exec.Command("setx", key, value)
		return cmd.Run()
	} else if runtime.GOOS == "linux" || runtime.GOOS == "darwin" {
		cmd := exec.Command("sudo", "launchctl", "setenv", key, value)
		return cmd.Run()
	}
	return nil
}

func serverMetrics(listenAddress, metricsPath string) error {
	http.Handle(metricsPath, promhttp.Handler())
	http.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		w.Write([]byte(`
			<html>
			<head><title>ConfigMap Reload Metrics</title></head>
			<body>
			<h1>ConfigMap Reload</h1>
			<p><a href='` + metricsPath + `'>Metrics</a></p>
			</body>
			</html>
		`))
	})
	return http.ListenAndServe(listenAddress, nil)
}

type webhookFlag []*url.URL

func (v *webhookFlag) Set(value string) error {
	u, err := url.Parse(value)
	if err != nil {
		return fmt.Errorf("invalid URL: %v", err)
	}
	*v = append(*v, u)
	return nil
}

func (v *webhookFlag) String() string {
	return fmt.Sprint(*v)
}
